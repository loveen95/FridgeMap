# FridgeMap
세미 프로젝트 - 냉장고 관리 웹

User - 민병학
Fridge - 이윤빈 & 김상래
Budget & Board - 주세인
