package com.zerock.fridge.service;

public class a {

}
