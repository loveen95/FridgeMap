package com.zerock.fridge.mapper;

public class a {

}
